<?php $__env->startSection('content'); ?>
    <h3 class="text-center mb-3 pt-3">Editar la nota <?php echo e($recursoActualizar->id); ?></h3>

    <form action="<?php echo e(route('update' , $recursoActualizar->id)); ?>" method="POST">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <input type="text" name="categoria" id="categoria" value="<?php echo e($recursoActualizar->categoria); ?>" class="form-control">
        </div>

        <div class="form-group">
            <input type="text" name="codigo" id="codigo" value="<?php echo e($recursoActualizar->codigo); ?>" class="form-control">
        </div>

        <div class="form-group">
            <input type="text" name="nombre" id="nombre" value="<?php echo e($recursoActualizar->nombre); ?>" class="form-control">
        </div>

        <div class="form-group">
            <input type="text" name="marca" id="marca" value="<?php echo e($recursoActualizar->marca); ?>" class="form-control">
        </div>

        <div class="form-group">
            <input type="text" name="serie" id="serie" value="<?php echo e($recursoActualizar->serie); ?>" class="form-control">
        </div>

        <button type="submit" class="btn btn-warning btn-block">Editar nota</button>
    </form>
    <?php if(session('update')): ?>
        <div class="alert alert-success mt-3">
            <?php echo e(session('update')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROGRAMS\xamp\htdocs\larastart\resources\views/recurso/editar.blade.php ENDPATH**/ ?>