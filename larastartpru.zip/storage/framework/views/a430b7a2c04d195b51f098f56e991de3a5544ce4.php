<?php $__env->startSection('content'); ?>
    <h3 class="text-center mb-3 pt-3">Editar la nota <?php echo e($personActualizar->id); ?></h3>

    <form action="<?php echo e(route('update' , $personActualizar->id)); ?>" method="POST">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <input type="text" name="identificacion" id="identificacion" value="<?php echo e($personActualizar->identificacion); ?>" class="form-control">
        </div>

        <div class="form-group">
            <input type="text" name="nombres" id="nombres" value="<?php echo e($personActualizar->nombres); ?>" class="form-control">
        </div>

        <div class="form-group">
            <input type="text" name="apellidos" id="apellidos" value="<?php echo e($personActualizar->apellidos); ?>" class="form-control">
        </div>

        <button type="submit" class="btn btn-warning btn-block">Editar nota</button>
    </form>
    <?php if(session('update')): ?>
        <div class="alert alert-success mt-3">
            <?php echo e(session('update')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\larastart\resources\views/user/editar.blade.php ENDPATH**/ ?>