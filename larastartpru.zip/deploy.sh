#Run Database Migrations
php artisan migrate: fresh


#Run Seeds
php artisan db:seed